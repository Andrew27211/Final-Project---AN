# Fundamentos-de-Android-Tarea-1
Se crea un proyecto con el uso de una imagen 9patch, soporte para múltiples pantallas y múltiples idiomas.
Subí otra carpeta que antes no me lo permitía, pero tuve problemas con las carpetas .idea y .gradle, a estas las metí en un rar. Perdonen las molestias. Todo el proyecto estaría ya aquí. 
